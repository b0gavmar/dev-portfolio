<template>
    <div class="container d-flex justify-content-center align-items-center">
    <div class="home bg-primary text-white text-center p-5 rounded shadow-lg">
      <h1 class="display-4 fw-bold text-uppercase">Welcome! My name is Martin Gavlik.</h1>
      <h2 class="lead fst-italic">I'm a fullstack developer.</h2>
    </div>
  </div>
</template>

<style scoped>
.home {
  max-width: 600px;
}
</style>

