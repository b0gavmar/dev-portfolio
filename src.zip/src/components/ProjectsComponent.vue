<script setup>

</script>

<template>
  <div class="container">
    <div class="d-flex align-items-center justify-content-center gap-3">
      <div class="column border card p-2">
        <h3>Projects I'm currently working on</h3>
        PipeLine
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
