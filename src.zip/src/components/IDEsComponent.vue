<script setup>

</script>

<template>
  <div class="container">
    <div class="d-flex align-items-center justify-content-center gap-3">
      <div class="column border card p-2">
        <h3>IDEs I've used through my studies</h3>
        VSC, VS, IntelliJ
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
