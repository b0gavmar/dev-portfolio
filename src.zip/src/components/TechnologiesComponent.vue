<script setup>

</script>

<template>
  <div class="container">
    <div class="d-flex align-items-center justify-content-center gap-3">
      <div class="column border card p-2">
        <h3>Technologies I'm most familiar with</h3>
        Html,CSS,JS,C# (WPF, Backend), Vue.js, MySql, Git(Conflict handling, Version control, Git bash)
      </div>
      <div class="column border card p-2">
        <h3>Technologies I've used</h3>
        Python, C#(Maui, Blazor, WinForms), Node.js, Java, Jwt, JQuery, Linux(Ubuntu), Cisco PacketTracer
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
