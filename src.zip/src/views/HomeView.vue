<script setup>

</script>

<template>
  <div class="container d-flex justify-content-center align-items-center">
    <div class="home bg-primary text-white text-center p-5 rounded shadow-lg">
      <h1 class="display-4 fw-bold text-uppercase">Welcome! My name is Martin Gavlik.</h1>
      <h2 class="lead fst-italic">I'm a fullstack developer.</h2>
    </div>
  </div>
  <div class="container-fluid ">
    <div class="d-flex align-items-center justify-content-center gap-3">
      <div class="card">Projects</div>
      <div class="card">Cv</div>
      <div class="card">Degrees</div>
      <div class="card">Certifications</div>
      <div class="card">Technologies</div>
      <div class="card">IDEs</div>
    </div>
  </div>
</template>

